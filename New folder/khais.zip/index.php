<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- my css -->
    <link rel="stylesheet" href="style.css">
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Baloo+Tammudu+2:wght@400;500;700;800&display=swap" rel="stylesheet">
    <!-- <link href="//db.onlinewebfonts.com/c/8c3ca23e360e5a8df02d9a7adafbc7e3?family=Bariol+Bold" rel="stylesheet" type="text/css"/> -->
    <link rel="shortcut icon" href="fav.png" >
    <title>Samdexs</title>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col logo">
          
        </div>       
      </div>
      <div class="row">
        <div class="col title">
        <h1>Our website is almost ready</h1>
        </div>
      </div>
      <div class="row">
        <div class="col ">
          <h2 class="subtitle">Jl. Mutiara Tim. IV No.20, Banjarbendo, Kec. Sidoarjo, Kabupaten Sidoarjo, Jawa Timur 61225</h2>
        </div>
      </div>
    </div>
  </body>
</html>